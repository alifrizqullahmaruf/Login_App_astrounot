package com.alif.login_app_alif

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.alif.login_app_alif.databinding.ActivityThirdBinding

class ThirdActivity : AppCompatActivity() {
    private lateinit var binding: ActivityThirdBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThirdBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Mengambil data yang dikirim dari activity_second
        val username = intent.getStringExtra("USERNAME")
        val email = intent.getStringExtra("EMAIL")
        val phone = intent.getStringExtra("PHONE")

        // Menggantikan teks pada TextView dengan data yang diterima
        binding.welcomeText.text = "Welcome $username"
        binding.emailText.text = "Your email: $email"
        binding.phoneText.text = "Your phone: $phone"
    }
}
