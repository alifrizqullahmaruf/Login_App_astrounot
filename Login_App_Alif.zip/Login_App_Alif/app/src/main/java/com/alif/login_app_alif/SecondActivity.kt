package com.alif.login_app_alif

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.alif.login_app_alif.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySecondBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Tambahkan tindakan klik untuk tombol "REGISTER"
        binding.registerBtn.setOnClickListener {
            val intentToThirdActivity = Intent(this@SecondActivity, ThirdActivity::class.java)
            startActivity(intentToThirdActivity)
        }
        // Tambahkan tindakan klik untuk kembali ke MainActivity
        binding.LoginPortal2.setOnClickListener {
            val intentToMainActivity = Intent(this@SecondActivity, MainActivity::class.java)
            startActivity(intentToMainActivity)
        }
        binding.registerBtn.setOnClickListener {
            val username = binding.username2.text.toString()
            val email = binding.Email2.text.toString()
            val phone = binding.Phone2.text.toString()

            val intentToThirdActivity = Intent(this@SecondActivity, ThirdActivity::class.java)
            intentToThirdActivity.putExtra("USERNAME", username)
            intentToThirdActivity.putExtra("EMAIL", email)
            intentToThirdActivity.putExtra("PHONE", phone)
            startActivity(intentToThirdActivity)
        }
        // Tambahkan tindakan klik untuk ikon GitHub
        binding.githubIcon.setOnClickListener {
            val githubUrl = "https://github.com/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(githubUrl))
            startActivity(intent)
        }

        // Tambahkan tindakan klik untuk ikon Google
        binding.googleIcon.setOnClickListener {
            val googleUrl = "https://www.google.com/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(googleUrl))
            startActivity(intent)
        }

        // Tambahkan tindakan klik untuk ikon Facebook
        binding.facebookIcon.setOnClickListener {
            val facebookUrl = "https://id-id.facebook.com/"
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(facebookUrl))
            startActivity(intent)
        }

    }

}
